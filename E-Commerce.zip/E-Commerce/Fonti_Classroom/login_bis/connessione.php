
<?php
	$hostname="localhost";
	$username="root";
	$password="";
	$dbname="ordini";
?>
